<DOCTYPE html>
<html lang="en">
 <head>
    <title>Welcome to Today!</title>
</head>
 <body>
    <h1>Welcome!</h1>
<div>
This file is
<?php
echo $_SERVER['DOCUMENT_ROOT']
 ?>
    </div>
</body>
</html>