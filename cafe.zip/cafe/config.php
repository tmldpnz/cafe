<?php
// MySQL credentials
define("DBHOST","localhost");
define("DBUSER","root");
define("DBPASSWORD","root");
define("DBDATABASE","cafe");
?>