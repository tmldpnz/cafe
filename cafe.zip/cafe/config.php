<?php
// MySQL credentials
define("DBUSER","root");
define("DBPASSWORD","root");
define("DBDATABASE","cafe");
define("HOST","localhost");
?>